# School Landing page
 This is a school landing page which I created with only basic html,css and Javascript.
